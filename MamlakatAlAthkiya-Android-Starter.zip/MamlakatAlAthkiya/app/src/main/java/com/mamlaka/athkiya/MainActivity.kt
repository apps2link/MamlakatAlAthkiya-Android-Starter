package com.mamlaka.athkiya

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val Ink = Color(0xFF26345A)
private val Purple = Color(0xFF7256C9)
private val Pink = Color(0xFFFF8BA7)
private val Gold = Color(0xFFFFC857)
private val Mint = Color(0xFF72D6B2)
private val Sky = Color(0xFF77C8F2)
private val Cream = Color(0xFFFFF9EF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MamlakaApp() }
    }
}

private enum class Screen { HOME, LETTERS, COUNTING, ANIMALS }

@Composable
private fun MamlakaApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var stars by remember { mutableIntStateOf(0) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Purple, secondary = Pink, background = Cream,
                surface = Color.White, onPrimary = Color.White, onSurface = Ink
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = Cream) {
                when (screen) {
                    Screen.HOME -> HomeScreen(stars, onOpen = { screen = it })
                    Screen.LETTERS -> LettersGame(onBack = { screen = Screen.HOME }, onWin = { stars += 1 })
                    Screen.COUNTING -> CountingGame(onBack = { screen = Screen.HOME }, onWin = { stars += 1 })
                    Screen.ANIMALS -> AnimalsGame(onBack = { screen = Screen.HOME }, onWin = { stars += 1 })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(stars: Int, onOpen: (Screen) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFEAF7FF), Cream)))
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("⭐ $stars", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("منطقة الأبطال الصغار", color = Ink.copy(alpha = .65f), fontSize = 13.sp)
        }
        Spacer(Modifier.height(22.dp))
        Text("👑", fontSize = 58.sp)
        Text("مملكة الأذكياء", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Purple)
        Text("نتعلّم ونلعب ونكتشف!", fontSize = 17.sp, color = Ink.copy(alpha = .75f))
        Spacer(Modifier.height(22.dp))
        Text("اختار عالمك وابدأ المغامرة", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        GameTile("🔤", "مدينة الحروف", "نتعرف على الحروف العربية", Pink) { onOpen(Screen.LETTERS) }
        GameTile("🔢", "جزيرة الأرقام", "نعدّ الأشياء ونكتشف الأرقام", Sky) { onOpen(Screen.COUNTING) }
        GameTile("🐾", "مزرعة الحيوانات", "مين صاحب الصوت؟", Mint) { onOpen(Screen.ANIMALS) }
        Spacer(Modifier.weight(1f))
        Text("اللعب الهادئ أحلى، وخد استراحة صغيرة كل شوية 💛", textAlign = TextAlign.Center, color = Ink.copy(alpha = .6f), fontSize = 12.sp)
    }
}

@Composable
private fun GameTile(emoji: String, title: String, subtitle: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).background(color, RoundedCornerShape(22.dp))
            .clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 37.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 13.sp, color = Ink.copy(alpha = .75f))
        }
        Text("←", fontSize = 25.sp, color = Ink)
    }
}

@Composable
private fun GameHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Ink) }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}

@Composable
private fun LettersGame(onBack: () -> Unit, onWin: () -> Unit) {
    var answered by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("اضغط على الحرف (أ)") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        GameHeader("مدينة الحروف", onBack)
        Spacer(Modifier.height(35.dp))
        Text("🐰", fontSize = 72.sp)
        Text("أرنب", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("ما أول حرف في كلمة أرنب؟", fontSize = 19.sp, color = Ink)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("ب", "أ", "س").forEach { letter ->
                AnswerButton(letter, letter == "أ", answered) {
                    answered = true
                    message = if (letter == "أ") "برافو عليك! ⭐" else "محاولة جميلة! جرّب تاني 💛"
                    if (letter == "أ") onWin()
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text(message, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple, textAlign = TextAlign.Center)
        if (answered) TextButton(onClick = { answered = false; message = "اضغط على الحرف (أ)" }) { Text("العب مرة تانية") }
    }
}

@Composable
private fun CountingGame(onBack: () -> Unit, onWin: () -> Unit) {
    var answered by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("عدّ التفاحات، كام تفاحة؟") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        GameHeader("جزيرة الأرقام", onBack)
        Spacer(Modifier.height(40.dp))
        Text("🍎  🍎  🍎", fontSize = 47.sp)
        Spacer(Modifier.height(18.dp))
        Text("كام تفاحة شايف؟", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("2", "3", "4").forEach { n ->
                AnswerButton(n, n == "3", answered) {
                    answered = true
                    message = if (n == "3") "ممتاز! أنت شاطر جدًا ⭐" else "قربت! عدّهم واحدة واحدة"
                    if (n == "3") onWin()
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text(message, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Purple, textAlign = TextAlign.Center)
        if (answered) TextButton(onClick = { answered = false; message = "عدّ التفاحات، كام تفاحة؟" }) { Text("العب مرة تانية") }
    }
}

@Composable
private fun AnimalsGame(onBack: () -> Unit, onWin: () -> Unit) {
    var answered by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("مين الحيوان اللي بيقول مياو؟") }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        GameHeader("مزرعة الحيوانات", onBack)
        Spacer(Modifier.height(38.dp))
        Text("🐱", fontSize = 83.sp)
        Text("مين صاحب الصوت؟", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("🐶", "🐱", "🐮").forEach { animal ->
                AnswerButton(animal, animal == "🐱", answered) {
                    answered = true
                    message = if (animal == "🐱") "مياااو! إجابة صحيحة ⭐" else "حاول مرة تانية يا بطل"
                    if (animal == "🐱") onWin()
                }
            }
        }
        Spacer(Modifier.height(25.dp))
        Text(message, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Purple, textAlign = TextAlign.Center)
        if (answered) TextButton(onClick = { answered = false; message = "مين الحيوان اللي بيقول مياو؟" }) { Text("العب مرة تانية") }
    }
}

@Composable
private fun AnswerButton(text: String, correct: Boolean, answered: Boolean, onClick: () -> Unit) {
    val color = if (answered && correct) Mint else Color.White
    Box(
        Modifier.size(82.dp).background(color, RoundedCornerShape(22.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 31.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}
